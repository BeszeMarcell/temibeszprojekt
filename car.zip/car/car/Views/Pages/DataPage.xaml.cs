﻿using car.ViewModels;
using System;
using System.Windows;
using Wpf.Ui.Common.Interfaces;
using System.IO;

namespace car.Views.Pages
{
    /// <summary>
    /// Interaction logic for DataView.xaml
    /// </summary>
    public partial class DataPage : INavigableView<ViewModels.DataViewModel>
    {
        public ViewModels.DataViewModel ViewModel
        {
            get;
        }

        public event EventHandler ButtonClicked;
        public int key = 3;
        public DataPage(ViewModels.DataViewModel viewModel)
        {
            ViewModel = viewModel;

            InitializeComponent();
        }

        private string Decrypt(string encryptedPassword, int key)
        {
            string decryptedMessage = "";
            foreach (char c in encryptedPassword)
            {
                if (Char.IsLetter(c))
                {
                    char baseChar = Char.IsUpper(c) ? 'A' : 'a';
                    char decryptedChar = (char)(((int)c - baseChar - key + 26) % 26 + baseChar);
                    decryptedMessage += decryptedChar;
                }
                else
                {
                    decryptedMessage += c;
                }
            }
            return decryptedMessage;
        }


        private void logbutton_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            string username = log1.Text;
            string encryptedPassword = log2.Text;
            string folderPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "password");
            string filePath = Path.Combine(folderPath, "registers.txt");
            if (File.Exists(filePath))
            {
                string[] lines = File.ReadAllLines(filePath);
                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');
                    if (parts.Length == 2)
                    {
                        string storedUsername = parts[0].Trim();
                        string storedEncryptedPassword = parts[1].Trim();
                        string decryptedPassword = Decrypt(storedEncryptedPassword, key);

                        if (username == storedUsername && encryptedPassword == decryptedPassword)
                        {
                            log1.Clear();
                            log2.Clear();
                            string siker = ("Sikeres bejelentkezés!");
                            MessageBox.Show("Sikeres bejelentkezés!", "Bejelentkezés", MessageBoxButton.OK, MessageBoxImage.Information);
                            ButtonClicked?.Invoke(this, EventArgs.Empty);
                            SettingsViewModel settingsViewModel = new SettingsViewModel();
                            SettingsPage settingsPage = new SettingsPage(settingsViewModel);
                            NavigationService.Navigate(settingsPage);
                            return;
                        }
                    }
                }
                log1.Clear();
                log2.Clear();
                string hiba = ("Hibás felhasználónév vagy jelszó!"); 
                MessageBox.Show("Hibás felhasználónév vagy jelszó!", "Bejelentkezés", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else
            {
                log1.Clear();
                log2.Clear();
                string nem = ("A regiszter fájl nem található!");
                MessageBox.Show(nem, "Bejelentkezés", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
