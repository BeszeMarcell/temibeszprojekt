﻿using System;
using Wpf.Ui.Common.Interfaces;
using System.IO;

namespace car.Views.Pages
{
    /// <summary>
    /// Interaction logic for SettingsPage.xaml
    /// </summary>
    public partial class SettingsPage : INavigableView<ViewModels.SettingsViewModel>
    {
        public ViewModels.SettingsViewModel ViewModel
        {
            get;
        }

        public SettingsPage(ViewModels.SettingsViewModel viewModel)
        {
            ViewModel = viewModel;

            InitializeComponent();
            InitializeWebView();
        }
        private async void InitializeWebView()
        {

            await webView.EnsureCoreWebView2Async(null);
            string basePath = AppDomain.CurrentDomain.BaseDirectory;
            string filePath = System.IO.Path.Combine(basePath, "Views", "Pages", "index.html");
            label1.Content = filePath;
            webView.CoreWebView2.Navigate(filePath);

        }
    }
}