﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using Wpf.Ui.Common.Interfaces;
using System.IO;

namespace car.Views.Pages
{

    class Register
    {
        public string Username
        { get; set; }

        public string Pass
        { get; set; }


    }


    public partial class DashboardPage : INavigableView<ViewModels.DashboardViewModel>
    {
        public int key = 3;
        private List<Register> registers = new List<Register>();
        public ViewModels.DashboardViewModel ViewModel
        {
            get;
        }

        public DashboardPage(ViewModels.DashboardViewModel viewModel)
        {
            ViewModel = viewModel;

            InitializeComponent();
        }
        private string Encrypt(string password, int key)
        {
            string encryptedMessage = "";
            foreach (char c in password)
            {
                if (Char.IsLetter(c))
                {
                    char baseChar = Char.IsUpper(c) ? 'A' : 'a';
                    char encryptedChar = (char)(((int)c - baseChar + key) % 26 + baseChar);
                    encryptedMessage += encryptedChar;
                }
                else
                {
                    encryptedMessage += c;
                }
            }
            return encryptedMessage;



        }

        private void regbutton_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            Register register1 = new Register();
            register1.Username = reg1.Text;
            register1.Pass = reg2.Text;
            string password = register1.Pass.ToString();
            if (string.IsNullOrEmpty(register1.Username) || string.IsNullOrEmpty(register1.Pass))
            {
                string regjo = "Kérlek töltsd ki az összes mezőt!";
                System.Windows.MessageBox.Show(regjo, "Regisztráció", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            if (register1.Pass.Length < 8)
            {
                System.Windows.MessageBox.Show("A jelszónak legalább 8 karakter hosszúnak kell lennie!", "Regisztráció", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            if (!register1.Pass.Any(char.IsUpper))
            {
                System.Windows.MessageBox.Show("A jelszónak tartalmaznia kell legalább egy nagybetűt!", "Regisztráció", MessageBoxButton.OK, MessageBoxImage.Information); ;
                return;
            }

            if (!Regex.IsMatch(register1.Pass, @"^[a-zA-Z0-9]+$"))
            {
                System.Windows.MessageBox.Show("A jelszó nem tartalmazhat ékezetes karaktereket vagy speciális karaktereket.", "Regisztráció", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }




            registers.Add(register1);
            reg1.Clear();
            reg2.Clear();
            System.Windows.MessageBox.Show("Sikeres Registráció!", "Registráció", MessageBoxButton.OK, MessageBoxImage.Information); ;
            string folderPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "password");
            Directory.CreateDirectory(folderPath);
            string filePath = Path.Combine(folderPath, "registers.txt");
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                foreach (Register register in registers)
                {
                    string encryptedPass = Encrypt(register.Pass, key);
                    writer.WriteLine($"{register.Username},{encryptedPass}");
                }
            }
        }
    }
}