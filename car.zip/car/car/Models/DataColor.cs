﻿using System.Windows.Media;

namespace car.Models
{
    public struct DataColor
    {
        public Brush Color { get; set; }
    }
}
